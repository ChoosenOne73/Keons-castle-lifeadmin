// ===== Modal helpers =====
const modalOverlay = document.getElementById('modalOverlay');
const modalSheet = document.getElementById('modalSheet');

function openModal(html) {
  modalSheet.innerHTML = html;
  modalOverlay.classList.add('show');
}
function closeModal() {
  modalOverlay.classList.remove('show');
}

// ===== Toast =====
let toastTimer = null;
function showToast(msg) {
  const toast = document.getElementById('toast');
  document.getElementById('toastMsg').textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
}

// ===== App menu (3-dot) =====
const BACK_TO_SITE_URL = '../index.html'; // update this to match your deployed folder structure
document.addEventListener('DOMContentLoaded', () => {
  const link = document.getElementById('backToSiteLink');
  if (link) link.href = BACK_TO_SITE_URL;
});
function openAppMenu() { document.getElementById('appMenuOverlay').classList.add('show'); }
function closeAppMenu() { document.getElementById('appMenuOverlay').classList.remove('show'); }

// ===== Post a task =====
function openPostTaskModal() {
  openModal(`
    <div class="modal-title">Post a task</div>
    <div class="modal-sub">Describe what you need — most tasks get a response within the hour.</div>
    <div class="modal-field">
      <label class="modal-label">Title</label>
      <input class="modal-input" id="ptTitle" placeholder="e.g. Help carrying groceries upstairs">
    </div>
    <div class="modal-field">
      <label class="modal-label">Category</label>
      <select class="modal-select" id="ptCategory">
        <option>Yard & Outdoor</option><option>Moving</option><option>Tech Help</option>
        <option>Errands</option><option>Handyman</option><option>Emergency</option>
      </select>
    </div>
    <div class="modal-field">
      <label class="modal-label">Description</label>
      <input class="modal-input" id="ptDesc" placeholder="A few details helps neighbors decide">
    </div>
    <div class="modal-field">
      <label class="modal-label">Payment</label>
      <select class="modal-select" id="ptPriceType" onchange="document.getElementById('ptPriceWrap').style.display = this.value==='fixed' ? 'block' : 'none'">
        <option value="fixed">Fixed price</option>
        <option value="tip">Open to tips</option>
      </select>
    </div>
    <div class="modal-field" id="ptPriceWrap">
      <label class="modal-label">Amount ($10–$50)</label>
      <input class="modal-input" id="ptPrice" type="number" min="10" max="50" value="20">
    </div>
    <div class="modal-field" style="display:flex;align-items:center;justify-content:space-between;">
      <label class="modal-label" style="margin:0;">Mark as emergency</label>
      <div class="toggle" id="ptUrgent" onclick="this.classList.toggle('on')"></div>
    </div>
    <div class="modal-btns">
      <button class="modal-btn secondary" onclick="closeModal()">Cancel</button>
      <button class="modal-btn primary" onclick="submitTask()">Post task</button>
    </div>
  `);
}

function submitTask() {
  const title = document.getElementById('ptTitle').value.trim();
  const category = document.getElementById('ptCategory').value;
  const desc = document.getElementById('ptDesc').value.trim() || 'No additional details provided.';
  const priceType = document.getElementById('ptPriceType').value;
  const price = priceType === 'fixed' ? Math.min(50, Math.max(10, parseInt(document.getElementById('ptPrice').value) || 20)) : null;
  const urgent = document.getElementById('ptUrgent').classList.contains('on');
  if (!title) { showToast('Please add a title for your task'); return; }

  const newTask = {
    id: 't' + Date.now(),
    title, category, desc,
    emoji: urgent ? '🚨' : '📌',
    location: 'Your neighborhood · nearby',
    poster: 'You', posterInitials: 'MR', rating: 4.9, verified: true,
    priceType, price, urgent, status: 'open'
  };
  tasks.unshift(newTask);
  closeModal();
  showToast('Task posted — neighbors nearby can see it now');
  renderFeed(); renderBrowse(); renderMyTasks();
  showScreen('screen-mytasks');
}

// ===== Task actions =====
function acceptTask(id) {
  const t = tasks.find(x => x.id === id);
  if (!t) return;
  t.status = 'accepted';
  t.acceptedBy = 'You';
  showToast(`You accepted "${t.title}"`);
  showTaskDetail(id);
  renderFeed(); renderBrowse(); renderMyTasks();
}
function completeTask(id) {
  const t = tasks.find(x => x.id === id);
  if (!t) return;
  t.status = 'completed';
  showToast(`Marked "${t.title}" as complete ✓`);
  showTaskDetail(id);
  renderFeed(); renderMyTasks();
}
function cancelTask(id) {
  const t = tasks.find(x => x.id === id);
  if (!t) return;
  tasks = tasks.filter(x => x.id !== id);
  showToast('Task canceled');
  showScreen('screen-mytasks');
  renderFeed(); renderBrowse();
}

// ===== Messages =====
function openConversation(msgId) {
  const m = messages.find(x => x.id === msgId);
  if (!m) return;
  renderConversationModal(m.name, m.initials, [
    { from: 'them', text: m.last }
  ]);
}
function openConversationWithPoster(taskId) {
  const t = tasks.find(x => x.id === taskId);
  if (!t) return;
  renderConversationModal(t.poster, t.posterInitials, [
    { from: 'them', text: `Hi! Thanks for checking out "${t.title}".` }
  ]);
}
function renderConversationModal(name, initials, thread) {
  openModal(`
    <div class="modal-title">${name}</div>
    <div id="chatThread" style="display:flex;flex-direction:column;gap:8px;margin:10px 0 14px;max-height:220px;overflow-y:auto;">
      ${thread.map(m => `<div style="align-self:${m.from === 'them' ? 'flex-start' : 'flex-end'};background:${m.from === 'them' ? '#0D0D0D' : 'rgba(96,165,250,0.18)'};border-radius:12px;padding:9px 12px;font-size:13px;color:#fff;max-width:80%;">${m.text}</div>`).join('')}
    </div>
    <div style="display:flex;gap:8px;">
      <input class="modal-input" id="chatInput" placeholder="Type a message…" style="flex:1;">
      <button class="modal-btn primary" style="flex:0 0 auto;padding:11px 16px;" onclick="sendChatMessage('${name}')">Send</button>
    </div>
  `);
}
function sendChatMessage(name) {
  const input = document.getElementById('chatInput');
  const text = input.value.trim();
  if (!text) return;
  const thread = document.getElementById('chatThread');
  thread.insertAdjacentHTML('beforeend', `<div style="align-self:flex-end;background:rgba(96,165,250,0.18);border-radius:12px;padding:9px 12px;font-size:13px;color:#fff;max-width:80%;">${text}</div>`);
  input.value = '';
  thread.scrollTop = thread.scrollHeight;
  setTimeout(() => {
    thread.insertAdjacentHTML('beforeend', `<div style="align-self:flex-start;background:#0D0D0D;border-radius:12px;padding:9px 12px;font-size:13px;color:#fff;max-width:80%;">Sounds good — see you soon!</div>`);
    thread.scrollTop = thread.scrollHeight;
  }, 900);
}

// ===== Settings modals =====
function openEditProfileModal() {
  const name = document.getElementById('profile-name').textContent;
  const email = document.getElementById('profile-email').textContent;
  openModal(`
    <div class="modal-title">Edit profile</div>
    <div class="modal-field"><label class="modal-label">Full name</label><input class="modal-input" id="editName" value="${name}"></div>
    <div class="modal-field"><label class="modal-label">Email</label><input class="modal-input" id="editEmail" value="${email}"></div>
    <div class="modal-btns">
      <button class="modal-btn secondary" onclick="closeModal()">Cancel</button>
      <button class="modal-btn primary" onclick="saveProfile()">Save changes</button>
    </div>
  `);
}
function saveProfile() {
  const name = document.getElementById('editName').value.trim();
  const email = document.getElementById('editEmail').value.trim();
  if (name) {
    document.getElementById('profile-name').textContent = name;
    const parts = name.trim().split(/\s+/);
    const initials = ((parts[0]?.[0] || '') + (parts[1]?.[0] || '')).toUpperCase();
    document.getElementById('profile-avatar').textContent = initials || 'ME';
    document.querySelectorAll('.avatar').forEach(a => a.textContent = initials || 'ME');
  }
  if (email) document.getElementById('profile-email').textContent = email;
  closeModal();
  showToast('Profile updated');
}

function openVerificationModal() {
  openModal(`
    <div class="modal-title">ID verification</div>
    <div class="modal-info-row"><div class="k">Status</div><div class="v" style="color:#34D399;">Verified ✓</div></div>
    <div class="modal-info-row"><div class="k">Method</div><div class="v">Government ID + selfie match</div></div>
    <div class="modal-info-row"><div class="k">Verified on</div><div class="v">Jan 12, 2026</div></div>
    <div class="modal-btns">
      <button class="modal-btn secondary" onclick="closeModal()">Close</button>
    </div>
  `);
}

function openPayoutModal() {
  openModal(`
    <div class="modal-title">Payout method</div>
    <div class="modal-info-row"><div class="k">Payout schedule</div><div class="v">Weekly, bundled with completed tasks</div></div>
    <div class="modal-sub" style="margin-top:14px;margin-bottom:0;">Set up your real payout account through Stripe -- this is where your task earnings actually get deposited.</div>
    <div class="modal-btns">
      <button class="modal-btn secondary" onclick="closeModal()">Close</button>
      <button class="modal-btn primary" onclick="startPayoutOnboarding()">Set up payouts \u2192</button>
    </div>
  `);
}

function startPayoutOnboarding() {
  const email = prompt('Enter your email to set up payouts:');
  if (!email) return;

  modalSheet.innerHTML = `<div class="modal-title">Redirecting to Stripe\u2026</div><div class="scan-anim"><div class="scan-spinner"></div></div>`;

  fetch('/.netlify/functions/connect-onboard', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: 'demo-provider-' + Date.now(), app: 'neighborhood-helper', email })
  })
    .then(res => res.json())
    .then(data => {
      if (data.url) {
        window.location.href = data.url;
      } else {
        showToast('Something went wrong -- please try again');
        closeModal();
      }
    })
    .catch(err => {
      console.error(err);
      showToast('Could not reach Stripe -- please try again');
      closeModal();
    });
}

function openPrivacyModal() {
  openModal(`
    <div class="modal-title">Privacy & safety</div>
    <div class="modal-info-row"><div class="k">Exact address shared</div><div class="v">Only after acceptance</div></div>
    <div class="modal-info-row"><div class="k">Background checks</div><div class="v">Required for verified badge</div></div>
    <div class="modal-info-row"><div class="k">Block a user</div><div class="v">Available in any chat</div></div>
    <div class="modal-btns">
      <button class="modal-btn secondary" onclick="closeModal()">Close</button>
    </div>
  `);
}

function openHelpModal() {
  openModal(`
    <div class="modal-title">Help & support</div>
    <div class="modal-sub">Have a question or ran into an issue with a task? We usually reply within a few hours.</div>
    <div class="modal-btns">
      <a class="modal-btn secondary" href="mailto:hello@keonscastlellc.com" style="text-decoration:none;display:flex;align-items:center;justify-content:center;">Email support</a>
      <button class="modal-btn primary" onclick="closeModal()">Done</button>
    </div>
  `);
}

function confirmSignOut() {
  openModal(`
    <div class="modal-title">Sign out?</div>
    <div class="modal-sub">You'll need to sign back in to see your tasks and messages.</div>
    <div class="modal-btns">
      <button class="modal-btn secondary" onclick="closeModal()">Cancel</button>
      <button class="modal-btn danger" onclick="doSignOut()">Sign out</button>
    </div>
  `);
}
function doSignOut() {
  closeModal();
  document.getElementById('signoutOverlay').classList.add('show');
}
function signBackIn() {
  document.getElementById('signoutOverlay').classList.remove('show');
  showScreen('screen-feed');
  showToast('Welcome back!');
}
