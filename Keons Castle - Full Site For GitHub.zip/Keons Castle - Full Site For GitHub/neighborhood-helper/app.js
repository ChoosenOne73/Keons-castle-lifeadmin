// ===== Task data =====
let tasks = [
  { id: 't1', title: 'Jump-start my car', category: 'Emergency', emoji: '🔋', desc: "Battery died in my driveway this morning. Need a jump — I have cables, just need someone with a working car for 10 minutes.", location: 'Oak Street area · 0.4 mi', poster: 'Dana K.', posterInitials: 'DK', rating: 4.8, verified: true, priceType: 'fixed', price: 15, urgent: true, status: 'open' },
  { id: 't2', title: 'Help moving a couch', category: 'Moving', emoji: '🛋️', desc: 'Moving a 3-seat couch from the garage to the second floor apartment. Should take about 30–40 minutes with two people.', location: 'Maple Ave · 0.7 mi', poster: 'Theo B.', posterInitials: 'TB', rating: 4.6, verified: true, priceType: 'fixed', price: 30, urgent: false, status: 'open' },
  { id: 't3', title: 'Set up my new WiFi router', category: 'Tech Help', emoji: '📶', desc: "Bought a new mesh router and can't get it connected. Should be quick for anyone who's done this before.", location: 'Birchwood Ct · 0.2 mi', poster: 'Priya S.', posterInitials: 'PS', rating: 5.0, verified: true, priceType: 'tip', price: null, urgent: false, status: 'open' },
  { id: 't4', title: 'Mow small front lawn', category: 'Yard & Outdoor', emoji: '🌿', desc: 'Small front yard, about 15x20 ft. I have a mower you can use, or bring your own.', location: 'Elm Street · 0.9 mi', poster: 'Carlos M.', posterInitials: 'CM', rating: 4.7, verified: false, priceType: 'fixed', price: 25, urgent: false, status: 'open' },
  { id: 't5', title: 'Fix a leaky faucet', category: 'Handyman', emoji: '🔧', desc: 'Kitchen faucet has a slow drip. Might just need a new washer — have basic tools on hand.', location: 'Riverside Dr · 1.1 mi', poster: 'Angela R.', posterInitials: 'AR', rating: 4.9, verified: true, priceType: 'fixed', price: 35, urgent: false, status: 'open' },
  { id: 't6', title: 'Pick up groceries', category: 'Errands', emoji: '🛒', desc: "Can't drive this week (minor surgery). Need a small grocery run from the store 5 min away, list provided.", location: 'Willow Ln · 0.5 mi', poster: 'Ben T.', posterInitials: 'BT', rating: 4.5, verified: true, priceType: 'fixed', price: 20, urgent: false, status: 'open' },
  { id: 't7', title: 'Assemble a bookshelf', category: 'Handyman', emoji: '🪚', desc: 'Flat-pack bookshelf, already completed once by me but I gave up halfway. Instructions included.', location: 'Pine Ridge · 1.3 mi', poster: 'You', posterInitials: 'MR', rating: 4.9, verified: true, priceType: 'fixed', price: 20, urgent: false, status: 'accepted', acceptedBy: 'You' },
  { id: 't8', title: 'Walk my dog this evening', category: 'Errands', emoji: '🐕', desc: "Stuck at work late, need someone to walk Biscuit around the block. He's friendly and leash-trained.", location: 'Cedar Ave · 0.6 mi', poster: 'You', posterInitials: 'MR', rating: 4.9, verified: true, priceType: 'tip', price: null, urgent: false, status: 'completed', acceptedBy: 'Sam W.' }
];

let messages = [
  { id: 'm1', name: 'Dana K.', initials: 'DK', last: "Thanks so much, on my way!", time: '2 min ago', taskId: 't1' },
  { id: 'm2', name: 'Priya S.', initials: 'PS', last: 'Is 5pm still good for the router setup?', time: '1 hr ago', taskId: 't3' },
  { id: 'm3', name: 'Sam W.', initials: 'SW', last: 'Biscuit was a great walk buddy 🐾', time: 'Yesterday', taskId: 't8' }
];

let currentTaskId = null;
let prevScreen = 'screen-feed';
const navMap = {
  'screen-feed': 'nav-feed',
  'screen-browse': 'nav-browse',
  'screen-mytasks': 'nav-mytasks',
  'screen-messages': 'nav-messages',
  'screen-settings': 'nav-settings'
};

function showScreen(id) {
  if (id === 'screen-detail') return;
  prevScreen = id;
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  if (navMap[id]) document.getElementById(navMap[id]).classList.add('active');
  if (id === 'screen-feed') renderFeed();
  if (id === 'screen-browse') renderBrowse();
  if (id === 'screen-mytasks') renderMyTasks();
  if (id === 'screen-messages') renderMessages();
  window.scrollTo(0, 0);
}

function goBack() {
  showScreen(prevScreen);
}

// ===== Rendering =====
function priceLabel(t) {
  return t.priceType === 'fixed' ? `$${t.price} fixed` : 'Open to tips';
}

function taskCardHTML(t, opts = {}) {
  const badgeClass = t.urgent ? 'b-red' : (t.priceType === 'fixed' ? 'b-green' : 'b-amber');
  const badgeText = t.urgent ? 'Urgent' : priceLabel(t);
  return `<div class="doc-card" data-cat="${t.category}" onclick="showTaskDetail('${t.id}')">
    <div class="doc-icon di-blue">${t.emoji}</div>
    <div class="doc-info"><div class="doc-name">${t.title}${t.urgent ? '<span class="urgent-tag">Urgent</span>' : ''}</div><div class="doc-sub">${t.poster === 'You' ? 'Posted by you' : t.poster} · ${t.location.split('·')[1]?.trim() || ''}</div></div>
    <div class="badge ${badgeClass}">${badgeText}</div>
  </div>`;
}

function renderFeed() {
  const openTasks = tasks.filter(t => t.status === 'open' && t.poster !== 'You');
  const emergency = openTasks.filter(t => t.urgent);
  document.getElementById('stat-open').textContent = openTasks.length;
  document.getElementById('stat-accepted').textContent = tasks.filter(t => t.status === 'accepted').length;
  document.getElementById('stat-completed').textContent = tasks.filter(t => t.status === 'completed').length;
  document.getElementById('emergencyBanner').style.display = emergency.length ? 'flex' : 'none';
  document.getElementById('feed-task-list').innerHTML = openTasks.map(t => taskCardHTML(t)).join('') || `<div style="color:rgba(255,255,255,0.3);font-size:13px;padding:20px;text-align:center;">No open tasks nearby right now.</div>`;
}

let activeCategory = 'All';
function renderBrowse() {
  const openTasks = tasks.filter(t => t.status === 'open' && t.poster !== 'You');
  const filtered = activeCategory === 'All' ? openTasks : openTasks.filter(t => t.category === activeCategory);
  document.getElementById('browse-count').textContent = `${filtered.length} open task${filtered.length === 1 ? '' : 's'} near you`;
  document.getElementById('browse-task-list').innerHTML = filtered.map(t => taskCardHTML(t)).join('') || `<div style="color:rgba(255,255,255,0.3);font-size:13px;padding:20px;text-align:center;">No tasks in this category yet.</div>`;
}

function setTaskFilter(el) {
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  el.classList.add('active');
  activeCategory = el.dataset.cat;
  renderBrowse();
}

function renderMyTasks() {
  const posted = tasks.filter(t => t.poster === 'You');
  const accepted = tasks.filter(t => t.acceptedBy === 'You');
  document.getElementById('mytasks-posted').innerHTML = posted.map(t => taskCardHTML(t)).join('') || `<div style="color:rgba(255,255,255,0.3);font-size:13px;padding:12px 0;">You haven't posted any tasks yet.</div>`;
  document.getElementById('mytasks-accepted').innerHTML = accepted.map(t => taskCardHTML(t)).join('') || `<div style="color:rgba(255,255,255,0.3);font-size:13px;padding:12px 0;">You haven't accepted any tasks yet.</div>`;
}

function renderMessages() {
  document.getElementById('messages-list').innerHTML = messages.map(m => `
    <div class="doc-card" onclick="openConversation('${m.id}')">
      <div class="doc-icon di-blue" style="border-radius:50%;">${m.initials}</div>
      <div class="doc-info"><div class="doc-name">${m.name}</div><div class="doc-sub">${m.last}</div></div>
      <div class="badge b-gray">${m.time}</div>
    </div>`).join('');
}

function showTaskDetail(id) {
  const t = tasks.find(x => x.id === id);
  if (!t) return;
  currentTaskId = id;
  document.getElementById('detail-title').textContent = t.category;
  document.getElementById('detail-emoji').textContent = t.emoji;
  document.getElementById('detail-name').textContent = t.title;
  document.getElementById('detail-sub').textContent = `${t.category} · ${t.location}`;
  const badge = document.getElementById('detail-badge');
  badge.textContent = priceLabel(t) + (t.urgent ? ' · Urgent' : '');
  badge.className = 'detail-days-inner ' + (t.urgent ? 'b-red' : (t.priceType === 'fixed' ? 'b-green' : 'b-amber'));
  document.getElementById('task-desc').textContent = t.desc;
  document.getElementById('task-location').textContent = t.location;

  document.getElementById('poster-card').innerHTML = `
    <div class="poster-avatar">${t.posterInitials}</div>
    <div class="poster-info">
      <div class="poster-name">${t.poster}${t.verified ? ' <span class="verified"><i class="ti ti-rosette-discount-check"></i></span>' : ''}</div>
      <div class="poster-rating"><span class="star">★</span> ${t.rating.toFixed(1)} · ${t.verified ? 'Verified neighbor' : 'Unverified'}</div>
    </div>`;

  const actionArea = document.getElementById('task-action-area');
  if (t.poster === 'You') {
    actionArea.innerHTML = t.status === 'open'
      ? `<div class="renew-btn" style="background:rgba(255,255,255,0.08);color:#fff;" onclick="cancelTask('${t.id}')">Cancel this task</div>`
      : `<div class="modal-info-row"><div class="k">Status</div><div class="v" style="text-transform:capitalize;">${t.status}${t.acceptedBy ? ' · ' + t.acceptedBy : ''}</div></div>`;
  } else if (t.status === 'open') {
    actionArea.innerHTML = `
      <div class="renew-btn" onclick="acceptTask('${t.id}')">Accept task →</div>
      <div class="renew-btn" style="background:rgba(255,255,255,0.08);color:#fff;margin-top:10px;" onclick="openConversationWithPoster('${t.id}')">Message ${t.poster}</div>`;
  } else if (t.acceptedBy === 'You') {
    actionArea.innerHTML = `
      <div class="renew-btn" onclick="completeTask('${t.id}')">Mark as complete ✓</div>
      <div class="renew-btn" style="background:rgba(255,255,255,0.08);color:#fff;margin-top:10px;" onclick="openConversationWithPoster('${t.id}')">Message ${t.poster}</div>`;
  } else {
    actionArea.innerHTML = `<div class="modal-info-row"><div class="k">Status</div><div class="v">Taken by ${t.acceptedBy || 'another neighbor'}</div></div>`;
  }

  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('screen-detail').classList.add('active');
}

// ===== Live clock =====
function updateClock() {
  const el = document.getElementById('clock');
  if (!el) return;
  const now = new Date();
  let h = now.getHours();
  const m = now.getMinutes().toString().padStart(2, '0');
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  el.textContent = `${h}:${m}`;
}
updateClock();
setInterval(updateClock, 30000);

document.addEventListener('DOMContentLoaded', () => {
  renderFeed();
  renderBrowse();
});

// ===== PWA: Service worker registration =====
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(err => {
      console.warn('Service worker registration failed:', err);
    });
  });
}
